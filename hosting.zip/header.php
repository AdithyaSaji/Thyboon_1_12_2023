<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <styles class="css"></styles>
    <style>

     .login-btn{
        
        margin-right: 35px;
      } 
    </style>
    <link rel="stylesheet" href="style.css">
    <title>Thyboon Home</title>
  </head>
  <body>
 <div class="hero">
    <nav> 
    <!-- <img src="Images/logo(2).jpg" class="logo"> -->
      <ul>
        <li><a href="Index.php"><h5><b>Home</b></h5></a></li>
        <li><a href="aboutus.php"><h5><b>About Us</b></h5></a></li>
        <li><a href="services.php"><h5><b>Services</b></h5></a></li>
        <li><a href="pricing.php"><h5><b>Pricing</b></h5></a></li>
        <li><a href="Contactus.php"><h5><b>Contact Us</b></h5></a></li>
      </ul>
        <a href="demopage.php" ><button class="login-btn anim">Demo</button></a>
        <a href="login.php" class="login-btn">Login</a>
        
      <div>
      </div>
    </nav>